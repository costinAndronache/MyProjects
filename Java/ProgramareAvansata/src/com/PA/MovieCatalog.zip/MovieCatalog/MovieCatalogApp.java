package com.PA.MovieCatalog;

import java.io.*;
import java.util.*;

public class MovieCatalogApp 
{
	private static String kCreate = "CREATE";
	private static String kDelete = "DELETE";
	private static String kSave = "SAVE";
	private static String kLoad = "LOAD";
	private static String kQuit = "QUIT";
	private static String kReport = "REPORT";
	private static String kRread = "READ";
	
	MovieDatabase mdb;
	
	public MovieCatalogApp()
	{
		mdb = new MovieDatabase();
		CreateController createCtrl = new CreateController();
		DeleteController deleteCtrl  = new DeleteController();
		SerializeController serCtrl = new SerializeController();
		DeserializeController desCtrl = new DeserializeController();
		ReportController repCtrl = new ReportController();
		
		MenuControllerFactory mcf = MenuControllerFactory.getSharedInstance();
		
		mcf.registerControllerForMenu(createCtrl, kCreate);
		mcf.registerControllerForMenu(deleteCtrl, kDelete);
		mcf.registerControllerForMenu(serCtrl, kSave);
		mcf.registerControllerForMenu(desCtrl, kLoad);
		mcf.registerControllerForMenu(repCtrl, kReport);
	}
	
	
	public void run()
	{
		String option = "";
		String[] menuItems = {kCreate, kRread, kDelete, kSave, kLoad, kReport, kQuit };
		
		Scanner scanner = new Scanner(new InputStreamReader(System.in));
		scanner.useDelimiter("\\n");
		
		while(true)
		{
			
			System.out.println("\n\n------------------------------\n\n");
			
			System.out.println("Available options: ");
			for(int i=0; i<menuItems.length; i++)
			{
				System.out.println("" + (i+1) + ". " + menuItems[i]);
			}
			
			System.out.println("Please insert an option:");
			
			option = scanner.nextLine();
			

			
			if(option.equals(kQuit))
			{
				System.out.println("Will quit.");
				break;
			}
			
			if(option.equals(kRread))
			{
				System.out.println(mdb.toString());
				continue;
			}
			
			boolean found = false;
			for(int i=0; i<menuItems.length; i++)
			{
				if(option.equals(menuItems[i]))
				{
					MenuController mc = MenuControllerFactory.getSharedInstance().getControllerForMenu(option);
					System.out.println("--------");
					mc.runWithDatabase(mdb);
					found = true;
				}
			}
			
			if(found == false)
			{
				System.out.println("Unrecognized option. Please try again.");
			}
		}
		
		scanner.close();
	}
	
	
	public static void main(String[] args)
	{
		MovieCatalogApp app = new MovieCatalogApp();
		app.run();
	}
}
