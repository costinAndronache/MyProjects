package com.PA.MovieCatalog;

public abstract class MenuController 
{
	public abstract void runWithDatabase(MovieDatabase db);
}
