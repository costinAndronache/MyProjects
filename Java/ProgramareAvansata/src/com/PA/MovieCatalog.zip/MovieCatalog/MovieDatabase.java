package com.PA.MovieCatalog;

import java.util.*;
import java.io.*;

public class MovieDatabase 
{
	private List<Movie> moviesList;
	
	public MovieDatabase() {
		// TODO Auto-generated constructor stub
		this.moviesList = new ArrayList<Movie>();
	}
	
	public void addNewMovie(Movie m)
	{
		this.moviesList.add(m);
	}
	
	public void removeMovieWithName(String name)
	{
		Movie m = this.findMovieWithName(name);
		if(m != null)
		{
			this.moviesList.remove(m);
		}
	}
	
	public Movie findMovieWithName(String name)
	{
		
		for(int i=0; i<this.moviesList.size(); i++)
		{
			Movie m = this.moviesList.get(i);
			if(m.getName().equals(name) == true)
			{
				return m;
			}
		}
		
		return null;
	}
	
	public void serializeToFile(String filename) throws Exception
	{
		File file = new File(filename);
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
		
		oos.writeInt(this.moviesList.size());
		
		for(Movie m : this.moviesList)
		{
			oos.writeObject(m);
		}

		oos.close();
	}
	
	@SuppressWarnings("unchecked")
	public void deserializeFromFile(String filename) throws Exception
	{
		File file = new File(filename);
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
		
		int numOfMovies = ois.readInt();
		
		for(int i=1; i<=numOfMovies; i++)
		{
			Movie m = (Movie)ois.readObject();
			this.moviesList.add(m);
		}
		ois.close();
	}
	
	public List<Movie> getListOfMovies()
	{
		return this.moviesList;
	}
	
	public Map<String, List<Movie>> getListOfMoviesGroupedByCategory()
	{
		Map<String, List<Movie>> lists = new HashMap<String,List<Movie>>();
		
		List<String> listOfCategories = new ArrayList<String>();
		
		for(Movie m : this.moviesList)
		{
			String[] catList = m.getCategoriesList();
			for(int i=0; i<catList.length; i++)
			{
				String cat = catList[i];
				
				if( this.stringExistsInList(listOfCategories, cat) == false)
				{
					listOfCategories.add(cat);
					List<Movie> aList = new ArrayList<Movie>();
					lists.put(cat, aList);
				}
				
			}
		}
		
		for(String category : listOfCategories)
		{
			for(Movie m : this.moviesList)
			{
				if(m.belongsToCategory(category))
				{
					lists.get(category).add(m);
				}
			}
		}
		
		
		return lists;
	}
	
	private boolean stringExistsInList(List<String> list, String s)
	{
		for(String ss : list)
		{
			if(ss.equals(s))
				return true;
		}
		
		return false;
	}
	
	@Override
	public String toString()
	{
		String res = "";
		for(Movie m : this.moviesList)
		{
			res += m.toString() + "\n";
		}
		return res;
	}
}
