package com.PA.MovieCatalog;

import java.util.*;
import java.io.*;

import freemarker.template.*;




public class ReportController extends MenuController 
{
	private static String kCatListKey = "categoriesListKey";
	private static String kCatNameKey = "categoryNameKey";
	private static String kMovieListKey = "movieListKey";
	private static String kSortingKey = "sortingKey";
	
    Configuration cfg = new Configuration(Configuration.VERSION_2_3_22);

    
    public ReportController() {
    	
    	cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		// TODO Auto-generated constructor stub
    	try {
			cfg.setDirectoryForTemplateLoading(new File("templates"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
	}
    
    
	@Override
	public void runWithDatabase(MovieDatabase db) 
	{
		String location;
		System.out.println("Please insert the filepath, including the filename: ");
		Scanner s = new Scanner(new InputStreamReader(System.in));
		location  = s.nextLine();
		File file = new File(location);
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean keepAsking = true;
		String opt = "";
		while(keepAsking)
		{
			keepAsking = false;
			System.out.println("Would you like your movies sorted by NAME or by RATING ?");
			opt = s.nextLine();
			if(opt.equals("NAME") || opt.equals("RATING"))
				break;
		}
		
		Map<String, List<Movie>> categoriesMap = db.getListOfMoviesGroupedByCategory();
		Comparator<Movie> comparator;
		
		if(opt.equals("NAME"))
		{
			comparator = new Comparator<Movie>() 
					{
				@Override
				public int compare(Movie o1, Movie o2) {
					// TODO Auto-generated method stub
					return o1.getName().compareTo(o2.getName());
					
				}
			};
			
			
		}
		else
		{
			comparator = new Comparator<Movie>() {
				@Override
				public int compare(Movie o1, Movie o2) {
					// TODO Auto-generated method stub
					if(o1.getRating() < o2.getRating())
						return 1;
					return 0;
				}
			};
		}
		
		for(String key : categoriesMap.keySet())
		{
			Collections.sort(categoriesMap.get(key), comparator);
		}
		
		Map<String, Object > dataModel =  new HashMap<String, Object>();
		
		List<Map < String, Object>> theList = new ArrayList<Map<String, Object>>();
		
		for(String catName : categoriesMap.keySet())
		{
			Map<String, Object> catElement = new HashMap<String, Object>();
			catElement.put(kCatNameKey, catName);
			List<String> movieList = new ArrayList<String>();
			
			for(Movie m : categoriesMap.get(catName))
			{
				movieList.add(m.getName());
			}
			
			catElement.put(kMovieListKey, movieList);
			
			theList.add(catElement);
		}
		dataModel.put(kCatListKey, theList);
		dataModel.put(kSortingKey, opt);
		
		Template temp;
		try {
			temp = cfg.getTemplate("template.ftl");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Something unexpected happened. Check your template file." + e.getMessage());
		 return;
		}
		
		try {
			FileWriter fw = new FileWriter(file);
			temp.process(dataModel, fw);
			fw.close();
		} catch (IOException  | TemplateException e) {
			// TODO Auto-generated catch block
			System.out.println("The path specified to the file is invalid or there must be something wrong with the template file.");
			return;
		}
		
	}

}
