package com.PA.MusicApp;

public abstract class Command 
{
	public abstract String executeWithString(String arg);
}
